public class Asistente {
    private final String nombre;
    private final String correo;
    private final String telefono;
    private final String curp;
    private final String edad;
    private final String institucion;

    public Asistente(String nombre, String correo, String telefono, String curp, String edad, String institucion) {
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.curp = curp;
        this.edad = edad;
        this.institucion = institucion;
    }

    public String getNombre()      { return nombre; }
    public String getCorreo()      { return correo; }
    public String getTelefono()    { return telefono; }
    public String getCurp()        { return curp; }
    public String getEdad()        { return edad; }
    public String getInstitucion() { return institucion; }

    @Override
    public String toString() {
        return String.format(
            "Nombre: %s | Correo: %s | Teléfono: %s | CURP: %s | Edad: %s | Institución: %s",
            nombre, correo, telefono, curp, edad, institucion
        );
    }
}

