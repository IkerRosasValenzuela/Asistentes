import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class RegistroGUI extends JFrame {
    private final JTextField campoNombre = new JTextField();
    private final JTextField campoCorreo = new JTextField();
    private final JTextField campoTelefono = new JTextField();
    private final JTextField campoCurp = new JTextField();
    private final JTextField campoEdad = new JTextField();
    private final JTextField campoInstitucion = new JTextField();
    private final JTextArea areaConsulta = new JTextArea();
    private final DBHelper db = new DBHelper();

    public RegistroGUI() {
        setTitle("Registro de Asistentes");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 450);
        setLocationRelativeTo(null);
        crearGUI();
    }

    private void crearGUI() {
        JTabbedPane pestañas = new JTabbedPane();

        // Panel de registro
        JPanel panelRegistro = new JPanel(new BorderLayout());
        JPanel formulario = new JPanel(new GridLayout(8, 2, 5, 5));

        formulario.add(new JLabel("Nombre:"));
        formulario.add(campoNombre);
        formulario.add(new JLabel("Correo:"));
        formulario.add(campoCorreo);
        formulario.add(new JLabel("Teléfono:"));
        formulario.add(campoTelefono);
        formulario.add(new JLabel("CURP:"));
        formulario.add(campoCurp);
        formulario.add(new JLabel("Edad:"));
        formulario.add(campoEdad);
        formulario.add(new JLabel("Institución:"));
        formulario.add(campoInstitucion);

        JButton btnRegistrar = new JButton("Registrar");
        btnRegistrar.addActionListener(e -> registrarAsistente());

        formulario.add(new JLabel());
        formulario.add(btnRegistrar);

        JLabel link = new JLabel("<html><a href=''>Visita nuestra página</a></html>");
        link.setCursor(new Cursor(Cursor.HAND_CURSOR));
        link.setForeground(Color.BLUE);
        link.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                try {
                    Desktop.getDesktop().browse(new java.net.URI("https://www.canva.com/design/DAGmoO2GnGo/m3h9-ZN-lu_RSvi3Xw2dpQ/watch?utm_content=DAGmoO2GnGo&utm_campaign=designshar"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        panelRegistro.add(formulario, BorderLayout.CENTER);
        panelRegistro.add(link, BorderLayout.SOUTH);

        // Panel de consulta
        JPanel panelConsulta = new JPanel(new BorderLayout());
        areaConsulta.setEditable(false);
        JButton btnActualizar = new JButton("Actualizar Lista");
        btnActualizar.addActionListener(e -> mostrarAsistentes());

        panelConsulta.add(new JScrollPane(areaConsulta), BorderLayout.CENTER);
        panelConsulta.add(btnActualizar, BorderLayout.SOUTH);

        pestañas.addTab("Registro", panelRegistro);
        pestañas.addTab("Consulta", panelConsulta);

        add(pestañas);
    }

    private void registrarAsistente() {
        String nombre = campoNombre.getText().trim();
        String correo = campoCorreo.getText().trim();
        String telefono = campoTelefono.getText().trim();
        String curp = campoCurp.getText().trim();
        String edad = campoEdad.getText().trim();
        String institucion = campoInstitucion.getText().trim();

        if (nombre.isEmpty() || correo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nombre y correo son obligatorios.");
            return;
        }

        Asistente a = new Asistente(nombre, correo, telefono, curp, edad, institucion);
        db.insertarAsistente(a);

        JOptionPane.showMessageDialog(this, "Asistente registrado correctamente.");

        campoNombre.setText("");
        campoCorreo.setText("");
        campoTelefono.setText("");
        campoCurp.setText("");
        campoEdad.setText("");
        campoInstitucion.setText("");
    }

    private void mostrarAsistentes() {
        ArrayList<Asistente> lista = db.obtenerAsistentes();
        areaConsulta.setText("");
        for (Asistente a : lista) {
            areaConsulta.append(a.toString() + "\n");
        }
    }
}
